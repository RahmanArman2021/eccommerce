<?php # Script 19.5 - index.php
// This is the main page for the site.

// Set the page title and include the HTML header:
$page_title = 'Make an Impression!';
include('includes/header.html');
?>
<h1 style="color:blue">Never give up</h1>
<p>Welcome to our site....please use the links above...blah, blah, blah.</p>
<p>Welcome to our site....please use the links above...blah, blah, blah.</p>

<?php include('includes/footer.html'); ?>
