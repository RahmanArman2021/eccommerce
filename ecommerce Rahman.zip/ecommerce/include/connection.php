<?php
  $conn = mysqli_connect("localhost","root","","ecommerce");
  if (!$conn) {
    echo "one Error Occured!".mysqli_error_connection($conn);
  }





 ?>
