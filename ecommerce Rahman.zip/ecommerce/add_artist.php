<?php

include("include/connection.php");

if(isset($_GET["firstname"])){



  if(!empty($_GET["firstname"])){
  $firstname = $_GET["firstname"];
  }
  if (!empty($_GET["lastname"])) {
  $lastname = $_GET["lastname"];
  }
  $midname = $_GET["middlename"];
  $sql = "INSERT INTO artists values(NULL,'$firstname','$midname','$lastname')";
  if(mysqli_query($conn,$sql)){
    echo "successfully Inserted one Record";

  }else {
    echo "one record not Inserted plz try again";
  }
}

 ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Add artist</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js">
    </script>
    <script src="js/jquery.min.js">

    </script>
    <link rel="stylesheet" href="css/myCSS.css">
  </head>
  <body>
    <div class="container">


    <h1 align="center">Add a Print</h1>

    <form method="get" class="form">

      <fieldset>
        <legend><b>Fill out to add an artist</b></legend>
        <b>First Name: </b> <input type="text" name="firstname" ><br><br>

        <b>Middle Name: </b> <input type="text" name="middlename" ><br><br>
        <b>Last Name: </b> <input type="text" name="lastname" ><br><br>
      </fieldset>
      <button type="submit" name="button" class="btn btn-success">Submit</button>
    </form>
    
</div>
  </body>
</html>
