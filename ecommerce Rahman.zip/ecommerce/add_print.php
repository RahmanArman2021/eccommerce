<?php
if(isset($_POST["printname"])){
  if(!empty($_POST["printname"])){
    $printname = $_POST["printname"];

  }if(!empty($_POST["image"])){
    $printname = $_POST["image"];

  }
  if(!empty($_POST["artist"])){
    $printname = $_POST["artist"];

  }
  $price = $_POST["price"];
  $size= $_POST["size"];
  $text = $_POST["text"];
include("include/connection.php");
mysqli_query($conn,"INSERT INTO prints values('Null',)");


}







 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js">

    </script>
    <script src="js/jquery.min.js">

    </script>
  </head>
  <body style="background-color: lightblue;">
    <h3 style="color:green;">Prepared BY: Abdul Rahman Arman</h3>
    <div class="container">


    <form class="from" action="index.html" method="post">
      <table>


      <legend>Fill Out the Form to add a print to the catalog</legend>
<tr><td><b>Print Name: </td><td></b><input type="text" name="printname"></td></tr>
<tr><td><b>Image</b> </td><td><input type="file" name="image"></td></tr>
<tr><td><b>Artists</b></td><td><select class="artits" name ="artist">
  <option>Select One</option>

</select></td></tr>
<tr><td><b>Price</b></td><td><input type="text" name="price"></td></tr>
<tr><td><b>Size</b></td><td><input type="text" name="size"></td></tr>
<tr><td><b>Description</b></td><td><textarea name="text" rows="3" cols="30"></textarea></td></tr>
</table>
    </form>
    <button type="submit" name="button" class="btn btn-success">Submit</button>
  </div>
  </body>
</html>
